"""
非接触式多模态助手
一款适用于会议 / 医疗 / 公共自助终端场景的非接触式多模态交互演示系统。

功能特性:
- 基于 MediaPipe 实现摄像头实时手势识别
- 可选：麦克风录音 + 基于 OpenAI 兼容接口的自动语音识别（ASR）
- 可选：基于 OpenAI 兼容接口的大语言模型（LLM）应答
- 可选：基于 pyttsx3 的语音合成（TTS）
- 基于场景的交互模式：
    1) 会议模式
    2) 医疗模式
    3) 公共终端模式
- 屏幕中文平视显示（HUD）与动画反馈

运行:
    先填入你的api后，cmd输入下一行
    python no_touch_multimodal_assistant.py

环境变量:
    LLM_API_KEY, LLM_BASE_URL, LLM_MODEL
    ASR_API_KEY, ASR_BASE_URL, ASR_MODEL
    TTS_ENABLED=1 or 0
    CAMERA_INDEX=0

依赖库:
    opencv-python, mediapipe, numpy, pillow, openai, sounddevice, SpeechRecognition, pyttsx3
"""

from __future__ import annotations

import platform
import base64
import math
import os
import random
import tempfile
import threading
import time
import wave
from collections import Counter, deque
from dataclasses import dataclass
from typing import Deque, Dict, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

# -------- 可选依赖库 --------
try:
    import mediapipe as mp
    MEDIA_PIPE_AVAILABLE = True
except Exception:
    MEDIA_PIPE_AVAILABLE = False
    mp = None  # type: ignore

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except Exception:
    OPENAI_AVAILABLE = False
    OpenAI = None  # type: ignore

try:
    import sounddevice as sd
    SOUNDDEVICE_AVAILABLE = True
except Exception:
    SOUNDDEVICE_AVAILABLE = False
    sd = None  # type: ignore

try:
    import speech_recognition as sr
    SPEECH_RECOGNITION_AVAILABLE = True
except Exception:
    SPEECH_RECOGNITION_AVAILABLE = False
    sr = None  # type: ignore

try:
    import pyttsx3
    TTS_AVAILABLE = True
except Exception:
    TTS_AVAILABLE = False
    pyttsx3 = None  # type: ignore


# -----------------------------
# 配置
# -----------------------------
@dataclass
class Config:
    camera_index: int = int(os.getenv("CAMERA_INDEX", "0"))
    fps: int = 30
    width: int = 1280
    height: int = 720

    gesture_smooth_window: int = 7
    gesture_confirm_count: int = 4
    gesture_cooldown: float = 0.55#冷却时间，防止过载
    trail_length: int = 14
    max_animations: int = 180#如果画面较卡顿，降低动画数量上限

    voice_record_seconds: float = float(os.getenv("VOICE_RECORD_SECONDS", "5"))
    sample_rate: int = 16000
    #也可调用其他大模型，只需支持语音识别即可，这里的例子是deepseek-chat和qwen3-asr-flash
    llm_api_key: str = os.getenv("LLM_API_KEY", "请在这输入你的api_key")
    llm_base_url: str = os.getenv("LLM_BASE_URL", "https://api.deepseek.com/v1")
    llm_model: str = os.getenv("LLM_MODEL", "deepseek-chat")

    asr_api_key: str = os.getenv("ASR_API_KEY", "请在这输入你的api_key")
    asr_base_url: str = os.getenv("ASR_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")
    asr_model: str = os.getenv("ASR_MODEL", "qwen3-asr-flash")

    tts_enabled: bool = os.getenv("TTS_ENABLED", "1") != "0"
    speak_ai_reply: bool = os.getenv("SPEAK_AI_REPLY", "1") != "0"

    # BGR
    col_text: Tuple[int, int, int] = (255, 255, 255)
    col_bg: Tuple[int, int, int] = (26, 30, 39)
    col_accent: Tuple[int, int, int] = (0, 220, 255)
    col_ok: Tuple[int, int, int] = (80, 220, 120)
    col_warn: Tuple[int, int, int] = (0, 180, 255)
    col_alert: Tuple[int, int, int] = (60, 60, 255)


class Utils:
    @staticmethod
    def clamp(v, lo, hi):
        return max(lo, min(hi, v))

    @staticmethod
    def dist2d(a, b):
        return float(math.hypot(a[0] - b[0], a[1] - b[1]))

    @staticmethod
    def mid(a, b):
        return ((a[0] + b[0]) // 2, (a[1] + b[1]) // 2)

    @staticmethod
    def write_wav(path: str, audio: np.ndarray, sample_rate: int):
        audio = np.asarray(audio)
        if audio.ndim > 1:
            audio = audio.mean(axis=1)
        audio = np.clip(audio, -1.0, 1.0)
        pcm = (audio * 32767).astype(np.int16)
        with wave.open(path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm.tobytes())

    @staticmethod
    def load_font(size: int = 24):
        candidates = [
            "simhei.ttf",
            "msyh.ttc",
            "msyh.ttf",
            "C:/Windows/Fonts/simhei.ttf",
            "C:/Windows/Fonts/msyh.ttc",
            "C:/Windows/Fonts/msyh.ttf",
            "/System/Library/Fonts/PingFang.ttc",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        ]
        for path in candidates:
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                pass
        return ImageFont.load_default()

    @staticmethod
    def majority_vote(items: List[str]) -> Tuple[str, int]:
        if not items:
            return "无", 0
        c = Counter(items)
        return c.most_common(1)[0]


# -----------------------------
# 场景定义
# -----------------------------
SCENES = {
    "meeting": {
        "name": "会议协作模式",
        "desc": "无接触翻页、提问总结、确认与暂停",
        "prompt": (
            "你是一个会议场景下的多模态助手。用户正在进行演示、汇报或线上会议，"
            "请用简短、明确、自然的中文回复。优先输出适合会议的建议、总结和下一步行动。"
        ),
        "commands": {
            "左滑": "上一页 / 返回",
            "右滑": "下一页 / 前进",
            "握拳": "暂停 / 恢复",
            "OK": "确认 / 继续",
            "点赞": "确认理解 / 赞同",
            "食指指向": "激光指示 / 聚焦",
            "五指张开": "呼出菜单 / 全屏提示",
            "比心": "生成暖场反馈",
        },
    },
    "medical": {
        "name": "医疗陪护模式",
        "desc": "无接触呼叫、状态确认、症状描述",
        "prompt": (
            "你是一个医疗陪护与病房辅助助手。回复要非常简洁、平稳、清晰，优先给出确认、提醒和安全建议。"
            "如果出现急症相关内容，要建议立即呼叫医护人员。"
        ),
        "commands": {
            "握拳": "紧急呼叫",
            "OK": "确认已收到",
            "点赞": "状态正常",
            "食指指向": "查看详情",
            "五指张开": "展开提醒",
            "比心": "安抚反馈",
        },
    },
    "kiosk": {
        "name": "公共终端模式",
        "desc": "无接触菜单导航、信息查询、确认提交",
        "prompt": (
            "你是一个公共服务终端助手。请用短句帮助用户完成菜单导航、信息查询和确认操作。"
            "回复要清晰、礼貌、可执行。"
        ),
        "commands": {
            "左滑": "上一个菜单",
            "右滑": "下一个菜单",
            "OK": "确认选择",
            "点赞": "满意 / 确认",
            "握拳": "取消 / 返回",
            "五指张开": "主页 / 菜单总览",
        },
    },
}


# -----------------------------
# 手势识别
# -----------------------------
class GestureEngine:
    def __init__(self):
        if not MEDIA_PIPE_AVAILABLE:
            raise RuntimeError("mediapipe not installed. Please install mediapipe first.")
        self.mp_hands = mp.solutions.hands
        self.mp_draw = mp.solutions.drawing_utils
        self.hands = self.mp_hands.Hands(
            max_num_hands=2,
            model_complexity=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.7,
        )
        self.motion_history: Deque[Tuple[float, float, float]] = deque(maxlen=12)

    def process(self, frame_rgb):
        return self.hands.process(frame_rgb)

    def draw_landmarks(self, frame, hand_landmarks):
        self.mp_draw.draw_landmarks(frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)

    @staticmethod
    def _pt(lm, idx, w, h):
        return (int(lm[idx].x * w), int(lm[idx].y * h))

    @staticmethod
    def _dist_landmarks(lm, idx1, idx2, w, h):
        p1 = (lm[idx1].x * w, lm[idx1].y * h)
        p2 = (lm[idx2].x * w, lm[idx2].y * h)
        return float(math.hypot(p1[0] - p2[0], p1[1] - p2[1]))

    @staticmethod
    def _finger_extended_y(lm, tip, pip, margin=0.015):
        return lm[tip].y < lm[pip].y - margin

    @staticmethod
    def _finger_folded_y(lm, tip, pip, margin=0.01):
        return lm[tip].y > lm[pip].y + margin

    @staticmethod
    def _thumb_extended(lm, handedness_label=None):
        thumb_tip = lm[4]
        thumb_ip = lm[3]
        thumb_mcp = lm[2]
        index_mcp = lm[5]
        wrist = lm[0]

        d_tip_wrist = math.hypot(thumb_tip.x - wrist.x, thumb_tip.y - wrist.y)
        d_ip_wrist = math.hypot(thumb_ip.x - wrist.x, thumb_ip.y - wrist.y)
        outward = d_tip_wrist > d_ip_wrist + 0.02

        if handedness_label == "Right":
            side_rule = thumb_tip.x > thumb_ip.x - 0.02
        elif handedness_label == "Left":
            side_rule = thumb_tip.x < thumb_ip.x + 0.02
        else:
            side_rule = abs(thumb_tip.x - thumb_mcp.x) > 0.03

        thumb_up_like = thumb_tip.y < index_mcp.y - 0.015
        return outward and side_rule and thumb_up_like

    def classify_single_hand(self, hand_landmarks, handedness_label: Optional[str], w: int, h: int) -> Tuple[str, float]:
        lm = hand_landmarks.landmark

        thumb_ext = self._thumb_extended(lm, handedness_label)
        index_ext = self._finger_extended_y(lm, 8, 6)
        middle_ext = self._finger_extended_y(lm, 12, 10)
        ring_ext = self._finger_extended_y(lm, 16, 14)
        pinky_ext = self._finger_extended_y(lm, 20, 18)

        extended_count = sum([thumb_ext, index_ext, middle_ext, ring_ext, pinky_ext])
        fist_count = sum([
            self._finger_folded_y(lm, 8, 6),
            self._finger_folded_y(lm, 12, 10),
            self._finger_folded_y(lm, 16, 14),
            self._finger_folded_y(lm, 20, 18),
        ])

        thumb_tip_index_tip = self._dist_landmarks(lm, 4, 8, w, h)
        wrist = self._pt(lm, 0, w, h)
        index_tip = self._pt(lm, 8, w, h)
        thumb_tip = self._pt(lm, 4, w, h)
        palm_size = max(40.0, self._dist_landmarks(lm, 0, 9, w, h))

        # OK
        ok_score = 0.0
        if thumb_tip_index_tip < palm_size * 0.30:
            ok_score += 0.7
        if middle_ext and ring_ext and pinky_ext:
            ok_score += 0.3

        # 拇指向上
        thumbs_up_score = 0.0
        if thumb_ext:
            thumbs_up_score += 0.5
        if not index_ext and not middle_ext and not ring_ext and not pinky_ext:
            thumbs_up_score += 0.35
        if thumb_tip[1] < wrist[1]:
            thumbs_up_score += 0.15

        # 胜利 / V
        victory_score = 1.0 if index_ext and middle_ext and (not ring_ext) and (not pinky_ext) else 0.0

        # 数字 / 形态
        one_score = 1.0 if index_ext and not middle_ext and not ring_ext and not pinky_ext else 0.0
        three_score = 1.0 if index_ext and middle_ext and ring_ext and (not pinky_ext) else 0.0
        four_score = 1.0 if index_ext and middle_ext and ring_ext and pinky_ext and (not thumb_ext) else 0.0
        open_score = 1.0 if index_ext and middle_ext and ring_ext and pinky_ext and thumb_ext else 0.0
        fist_score = 1.0 if fist_count >= 4 and extended_count <= 1 else 0.0

        candidates = [
            ("OK", ok_score),
            ("点赞", thumbs_up_score),
            ("胜利", victory_score),
            ("三", three_score),
            ("四", four_score),
            ("五指张开", open_score),
            ("握拳", fist_score),
            ("食指指向", one_score),
        ]
        candidates.sort(key=lambda x: x[1], reverse=True)

        best_label, best_score = candidates[0]
        if best_score < 0.56:
            return "无", 0.0
        return best_label, float(best_score)

    def classify_two_hands(self, hand1, hand2, w: int, h: int) -> Tuple[str, float, Tuple[int, int]]:
        lm1 = hand1.landmark
        lm2 = hand2.landmark

        c1 = Utils.mid(self._pt(lm1, 0, w, h), self._pt(lm1, 9, w, h))
        c2 = Utils.mid(self._pt(lm2, 0, w, h), self._pt(lm2, 9, w, h))
        center = Utils.mid(c1, c2)
        center_dist = Utils.dist2d(c1, c2)

        thumb1 = self._pt(lm1, 4, w, h)
        thumb2 = self._pt(lm2, 4, w, h)
        index1 = self._pt(lm1, 8, w, h)
        index2 = self._pt(lm2, 8, w, h)

        thumb_dist = Utils.dist2d(thumb1, thumb2)
        index_dist = Utils.dist2d(index1, index2)

        p1_label, p1_score = self.classify_single_hand(hand1, None, w, h)
        p2_label, p2_score = self.classify_single_hand(hand2, None, w, h)

        if center_dist < w * 0.28 and thumb_dist < w * 0.12 and index_dist < w * 0.13:
            return "比心", 0.98, center
        if center_dist < w * 0.20 and thumb_dist < w * 0.18:
            return "双手合拢", 0.80, center
        if p1_label in ("五指张开",) and p2_label in ("五指张开",):
            return "双手张开", 0.86, center

        if p1_score >= p2_score:
            return p1_label, p1_score, c1
        return p2_label, p2_score, c2

    def detect_swipe(self, center_xy: Tuple[int, int]) -> str:
        t = time.time()
        self.motion_history.append((t, float(center_xy[0]), float(center_xy[1])))
        if len(self.motion_history) < self.motion_history.maxlen:
            return "无"

        t0, x0, y0 = self.motion_history[0]
        t1, x1, y1 = self.motion_history[-1]
        dt = t1 - t0
        if dt < 0.35:
            return "无"
        dx = x1 - x0
        dy = y1 - y0

        if abs(dx) > 170 and abs(dy) < 120:
            self.motion_history.clear()
            return "右滑" if dx > 0 else "左滑"
        return "无"


# -----------------------------
# 音频/AI服务
# -----------------------------
class VoiceService:
    def __init__(self, config: Config):
        self.config = config
        self.client = None
        if OPENAI_AVAILABLE and config.asr_api_key:
            try:
                self.client = OpenAI(api_key=config.asr_api_key, base_url=config.asr_base_url)
            except Exception:
                self.client = None

        self.tts_engine = None
        if TTS_AVAILABLE and config.tts_enabled:
            try:
                self.tts_engine = pyttsx3.init()
                try:
                    self.tts_engine.setProperty("rate", 190)
                except Exception:
                    pass
            except Exception:
                self.tts_engine = None

        self.recording = False
        self.status_text = "语音：未就绪"
        self.latest_transcript = ""
        self.lock = threading.Lock()

    def can_record(self) -> bool:
        return SOUNDDEVICE_AVAILABLE or SPEECH_RECOGNITION_AVAILABLE

    @staticmethod
    def _audio_mime_type(path: str) -> str:
        ext = os.path.splitext(path)[1].lower()
        if ext in (".wav", ".wave"):
            return "audio/wav"
        if ext == ".mp3":
            return "audio/mpeg"
        if ext in (".m4a", ".mp4"):
            return "audio/mp4"
        if ext == ".aac":
            return "audio/aac"
        if ext == ".flac":
            return "audio/flac"
        return "audio/wav"

    def transcribe_file(self, path: str) -> str:
        if not self.client:
            return ""

        with open(path, "rb") as f:
            audio_bytes = f.read()

        mime_type = self._audio_mime_type(path)
        data_uri = f"data:{mime_type};base64,{base64.b64encode(audio_bytes).decode()}"

        res = self.client.chat.completions.create(
            model=self.config.asr_model,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "input_audio",
                            "input_audio": {"data": data_uri},
                        }
                    ],
                }
            ],
            stream=False,
            extra_body={"asr_options": {"enable_itn": False}},
        )

        try:
            return (res.choices[0].message.content or "").strip()
        except Exception:
            return ""

    def start_record_and_transcribe_async(self, duration: float, sample_rate: int, on_done):
        with self.lock:
            if self.recording:
                return
            self.recording = True

        self.status_text = f"语音：录音中 {duration:.0f}s..."
        th = threading.Thread(
            target=self._record_and_transcribe_task,
            args=(duration, sample_rate, on_done),
            daemon=True,
        )
        th.start()

    def _record_and_transcribe_task(self, duration: float, sample_rate: int, on_done):
        transcript = ""
        err = ""

        try:
            if SOUNDDEVICE_AVAILABLE:
                audio = sd.rec(int(duration * sample_rate), samplerate=sample_rate, channels=1, dtype="float32")
                sd.wait()
                audio = np.squeeze(audio)
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                    tmp_path = f.name
                try:
                    Utils.write_wav(tmp_path, audio, sample_rate)
                    transcript = self.transcribe_file(tmp_path).strip()
                finally:
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass

            elif SPEECH_RECOGNITION_AVAILABLE:
                r = sr.Recognizer()
                with sr.Microphone(sample_rate=sample_rate) as source:
                    r.adjust_for_ambient_noise(source, duration=0.5)
                    audio_data = r.record(source, duration=duration)
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                    tmp_path = f.name
                try:
                    wav_bytes = audio_data.get_wav_data(convert_rate=sample_rate, convert_width=2)
                    with open(tmp_path, "wb") as wf:
                        wf.write(wav_bytes)
                    transcript = self.transcribe_file(tmp_path).strip()
                finally:
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass
            else:
                err = "缺少 sounddevice / speech_recognition，无法录音。"

            if not transcript and not err:
                err = "未识别到语音内容。"
        except Exception as e:
            err = f"语音处理失败：{str(e)[:120]}"

        self.latest_transcript = transcript
        self.status_text = "语音：已完成" if transcript else f"语音：{err}"
        on_done(transcript, err)

        with self.lock:
            self.recording = False

    def speak_async(self, text: str):
        if not self.tts_engine or not text.strip():
            return
        threading.Thread(target=self._speak_task, args=(text,), daemon=True).start()

    def _speak_task(self, text: str):
        try:
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
        except Exception:
            pass


class AIService:
    def __init__(self, config: Config):
        self.config = config
        self.client = None
        if OPENAI_AVAILABLE and config.llm_api_key:
            try:
                self.client = OpenAI(api_key=config.llm_api_key, base_url=config.llm_base_url)
            except Exception:
                self.client = None
        self.history: Deque[Tuple[str, str]] = deque(maxlen=10)
        self.latest_response = "等待触发..."
        self.latest_user_text = ""
        self.is_processing = False
        self.lock = threading.Lock()

    def ask_async(self, scene_key: str, gesture: str, transcript: str, on_done=None):
        if not self.client:
            self.latest_response = "LLM 未初始化：请检查 LLM_API_KEY / LLM_BASE_URL。"
            if on_done:
                on_done(self.latest_response)
            return

        user_text = transcript.strip()
        if not user_text:
            user_text = f"当前手势：{gesture}。请结合场景给出最合适的建议。"

        with self.lock:
            if self.is_processing:
                return
            self.is_processing = True

        self.latest_user_text = user_text
        self.latest_response = "思考中..."
        threading.Thread(target=self._task, args=(scene_key, gesture, user_text, on_done), daemon=True).start()

    def _task(self, scene_key: str, gesture: str, user_text: str, on_done=None):
        try:
            scene = SCENES.get(scene_key, SCENES["meeting"])
            system_prompt = scene["prompt"] + (
                "\n请严格结合用户语音、当前手势和场景状态做回应。"
                "输出尽量不超过 90 个汉字，直接给可执行结果，不要长篇解释。"
            )

            messages = [{"role": "system", "content": system_prompt}]
            for role, content in self.history:
                messages.append({"role": role, "content": content})

            user_prompt = (
                f"场景：{scene['name']}\n"
                f"当前手势：{gesture}\n"
                f"语音内容：{user_text}\n"
                f"请给出回复。"
            )
            messages.append({"role": "user", "content": user_prompt})

            res = self.client.chat.completions.create(
                model=self.config.llm_model,
                messages=messages,
                temperature=0.5,
            )
            content = res.choices[0].message.content.strip()
            if not content:
                content = "模型没有返回有效内容。"

            self.latest_response = content
            self.history.append(("user", user_prompt))
            self.history.append(("assistant", self.latest_response))
        except Exception as e:
            self.latest_response = f"LLM 请求出错：{str(e)[:140]}"
        finally:
            with self.lock:
                self.is_processing = False
            if on_done:
                on_done(self.latest_response)


# -----------------------------
# 动画特效部分
# -----------------------------
class Animation:
    def update(self):
        raise NotImplementedError

    def draw(self, frame):
        raise NotImplementedError

    def is_dead(self):
        return True


class AnimationManager:
    def __init__(self, limit=180):
        self.animations: List[Animation] = []
        self.limit = limit

    def add(self, anim: Animation):
        if len(self.animations) < self.limit:
            self.animations.append(anim)

    def update_and_draw(self, frame):
        active = []
        for a in self.animations:
            a.update()
            a.draw(frame)
            if not a.is_dead():
                active.append(a)
        self.animations = active


class RingPulse(Animation):
    def __init__(self, x, y, color=(0, 220, 255), start_radius=10, life=34):
        self.x, self.y = int(x), int(y)
        self.color = color
        self.radius = start_radius
        self.life = life

    def update(self):
        self.radius += 6
        self.life -= 1

    def draw(self, frame):
        alpha = max(self.life / 34.0, 0.0)
        col = tuple(int(c * alpha) for c in self.color)
        cv2.circle(frame, (self.x, self.y), int(self.radius), col, 2, cv2.LINE_AA)

    def is_dead(self):
        return self.life <= 0


class SparkParticle(Animation):
    def __init__(self, x, y, color=(255, 255, 255)):
        self.x = float(x) + random.uniform(-6, 6)
        self.y = float(y) + random.uniform(-6, 6)
        ang = random.uniform(0, 2 * math.pi)
        sp = random.uniform(2.5, 8.5)
        self.vx = math.cos(ang) * sp
        self.vy = math.sin(ang) * sp - random.uniform(0.0, 1.4)
        self.life = random.randint(22, 42)
        self.color = color
        self.size = random.randint(2, 4)

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.18
        self.vx *= 0.98
        self.life -= 1

    def draw(self, frame):
        alpha = max(self.life / 42.0, 0.0)
        col = tuple(int(c * alpha) for c in self.color)
        cv2.circle(frame, (int(self.x), int(self.y)), self.size, col, -1, cv2.LINE_AA)

    def is_dead(self):
        return self.life <= 0


class HeartBurst(Animation):
    def __init__(self, x, y, life=70):
        self.x, self.y = int(x), int(y)
        self.life = life
        self.angle = 0.0

    def update(self):
        self.angle += 0.1
        self.life -= 1

    def draw(self, frame):
        scale = 34 + int(10 * math.sin(self.angle * 2))
        pts = []
        for t in np.linspace(0, 2 * np.pi, 100):
            xs = 16 * np.sin(t) ** 3
            ys = 13 * np.cos(t) - 5 * np.cos(2 * t) - 2 * np.cos(3 * t) - np.cos(4 * t)
            x = int(self.x + xs * scale / 16)
            y = int(self.y - ys * scale / 16)
            pts.append((x, y))
        alpha = max(self.life / 70.0, 0.0)
        col = (int(255 * alpha), int(80 * alpha), int(180 * alpha))
        cv2.polylines(frame, [np.array(pts, dtype=np.int32)], True, col, 2, cv2.LINE_AA)

    def is_dead(self):
        return self.life <= 0


# -----------------------------
# 主程序
# -----------------------------
class TouchlessAssistantApp:
    def __init__(self):
        self.config = Config()
        self.scene_key = "meeting"
        self.scene_page = 1
        self.freeze = False
        self.show_help = True

        # -------- 摄像头初始化（增强兼容微信 / 腾讯会议）--------
        self.cap = None

        # Windows 优先使用 DirectShow
        if platform.system() == "Windows":
            self.cap = cv2.VideoCapture(self.config.camera_index, cv2.CAP_DSHOW)

            if not self.cap.isOpened():
                print("[WARN] CAP_DSHOW 打开失败，尝试默认后端...")
                self.cap = cv2.VideoCapture(self.config.camera_index)

        else:
            # Mac / Linux 使用默认
            self.cap = cv2.VideoCapture(self.config.camera_index)

        if not self.cap.isOpened():
            raise RuntimeError("无法打开摄像头。请检查 camera_index 或摄像头权限。")

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.height)
        self.cap.set(cv2.CAP_PROP_FPS, self.config.fps)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)  # 减少延迟 & 避免缓存冲突


        self.width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)) or self.config.width
        self.height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)) or self.config.height

        self.gesture_engine = GestureEngine()
        self.voice = VoiceService(self.config)
        self.ai = AIService(self.config)
        self.animations = AnimationManager(self.config.max_animations)

        self.font = Utils.load_font(24)
        self.font_small = Utils.load_font(18)
        self.font_bold = Utils.load_font(30)

        self.last_trigger_time = 0.0
        self.last_triggered_gesture = "无"

        self.raw_gesture_history: Deque[str] = deque(maxlen=self.config.gesture_smooth_window)
        self.stable_gesture = "无"
        self.stable_score = 0.0

        self.hand_centers: Dict[int, Deque[Tuple[int, int]]] = {
            0: deque(maxlen=self.config.trail_length),
            1: deque(maxlen=self.config.trail_length),
        }

        self.current_center = (self.width // 2, self.height // 2)
        self.latest_frame_gesture = "无"
        self.latest_hand_count = 0
        self.latest_confidence = 0.0
        self.latest_transcript = ""
        self.latest_reply = "等待触发..."
        self.events: Deque[str] = deque(maxlen=10)
        self.command_hint = "按 1/2/3 切换场景 | V 录音 | H 帮助 | Q 退出"

        self._push_event("系统已启动")
        if not MEDIA_PIPE_AVAILABLE:
            self._push_event("警告：mediapipe 未安装，无法识别手势")

    def _push_event(self, text: str):
        stamp = time.strftime("%H:%M:%S")
        self.events.appendleft(f"[{stamp}] {text}")

    def _scene(self):
        return SCENES[self.scene_key]

    def _switch_scene(self, key: str):
        if key not in SCENES:
            return
        self.scene_key = key
        self.scene_page = 1
        self._push_event(f"切换到 {SCENES[key]['name']}")
        self.latest_reply = f"已切换到 {SCENES[key]['name']}"

    def _record_done(self, transcript: str, err: str):
        if transcript:
            self.latest_transcript = transcript
            self._push_event(f"语音识别：{transcript}")
        else:
            self._push_event(err or "语音识别失败")

        self.ai.ask_async(self.scene_key, self.stable_gesture, transcript or "", on_done=self._ai_done)

    def _ai_done(self, reply: str):
        self.latest_reply = reply
        self._push_event(f"AI回复：{reply[:40]}")
        if self.config.speak_ai_reply:
            self.voice.speak_async(reply[:120])

    def trigger_effects(self, gesture: str, center: Tuple[int, int]):
        x, y = center
        if gesture == "比心":
            self.animations.add(HeartBurst(x, y))
            self.animations.add(RingPulse(x, y, color=(255, 100, 190), start_radius=16, life=42))
            for _ in range(12):
                self.animations.add(SparkParticle(x, y, color=(255, 140, 200)))
        elif gesture == "点赞":
            self.animations.add(RingPulse(x, y, color=(0, 240, 140), start_radius=12, life=34))
            for _ in range(10):
                self.animations.add(SparkParticle(x, y, color=(0, 240, 140)))
        elif gesture == "OK":
            self.animations.add(RingPulse(x, y, color=(0, 210, 255), start_radius=12, life=34))
            for _ in range(10):
                self.animations.add(SparkParticle(x, y, color=(0, 210, 255)))
        elif gesture == "握拳":
            for _ in range(18):
                self.animations.add(SparkParticle(x, y, color=(255, 80, 80)))
        elif gesture in ("五指张开", "双手张开"):
            self.animations.add(RingPulse(x, y, color=(255, 255, 255), start_radius=18, life=28))
        elif gesture in ("左滑", "右滑"):
            self.animations.add(RingPulse(x, y, color=(255, 220, 80), start_radius=10, life=28))
        elif gesture == "食指指向":
            self.animations.add(RingPulse(x, y, color=(255, 180, 60), start_radius=8, life=26))

    def _apply_command(self, gesture: str):
        scene = self._scene()

        if self.scene_key == "meeting":
            if gesture == "左滑":
                self.scene_page = max(1, self.scene_page - 1)
                self._push_event("上一页")
            elif gesture == "右滑":
                self.scene_page += 1
                self._push_event("下一页")
            elif gesture == "握拳":
                self.freeze = not self.freeze
                self._push_event("暂停画面" if self.freeze else "恢复画面")
            elif gesture == "OK":
                self._push_event("确认当前内容")
            elif gesture == "食指指向":
                self._push_event("聚焦到当前区域")
            elif gesture == "点赞":
                self._push_event("表示赞同")
            elif gesture == "比心":
                self._push_event("暖场反馈已触发")

        elif self.scene_key == "medical":
            if gesture == "握拳":
                self._push_event("紧急呼叫已触发")
                self.latest_reply = "已触发紧急呼叫提醒，请立即通知医护人员。"
            elif gesture == "OK":
                self._push_event("确认收到")
            elif gesture == "点赞":
                self._push_event("状态正常")
            elif gesture == "食指指向":
                self._push_event("展开病况详情")
            elif gesture == "比心":
                self._push_event("安抚反馈")
            elif gesture == "五指张开":
                self._push_event("展开提醒面板")

        elif self.scene_key == "kiosk":
            if gesture == "左滑":
                self.scene_page = max(1, self.scene_page - 1)
                self._push_event("菜单向左切换")
            elif gesture == "右滑":
                self.scene_page += 1
                self._push_event("菜单向右切换")
            elif gesture == "OK":
                self._push_event("确认选择")
            elif gesture == "点赞":
                self._push_event("满意并确认")
            elif gesture == "握拳":
                self._push_event("取消 / 返回")
            elif gesture == "五指张开":
                self._push_event("回到主页")

        # 通用逻辑：若识别到有效指令，则在文本为空的情况下调用 AI，生成上下文感知建议。
        if gesture in ("握拳", "OK", "点赞", "食指指向", "五指张开", "比心"):
            self.ai.ask_async(self.scene_key, gesture, "", on_done=self._ai_done)

    def _smooth_gesture(self, gesture: str, score: float) -> Tuple[str, float]:
        self.raw_gesture_history.append(gesture)
        stable, count = Utils.majority_vote(list(self.raw_gesture_history))
        stable_score = count / max(1, len(self.raw_gesture_history))
        if stable != "无" and stable_score >= 0.55:
            return stable, stable_score
        return "无", 0.0

    def _draw_panel(self, frame, x1, y1, x2, y2, alpha=0.60):
        overlay = frame.copy()
        cv2.rectangle(overlay, (x1, y1), (x2, y2), (18, 22, 30), -1)
        cv2.addWeighted(overlay, alpha, frame, 1 - alpha, 0, frame)
        cv2.rectangle(frame, (x1, y1), (x2, y2), (70, 80, 100), 1)

    def _put_text(self, frame, text: str, pos: Tuple[int, int], font, color=(255, 255, 255)):
        pil_img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(pil_img)
        draw.text(pos, text, font=font, fill=(int(color[2]), int(color[1]), int(color[0])))
        return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    def _draw_hud(self, frame, gesture: str, score: float, center: Tuple[int, int]):
        scene = self._scene()
        h, w = frame.shape[:2]

        # 顶栏
        self._draw_panel(frame, 0, 0, w, 78, alpha=0.78)
        frame = self._put_text(frame, "无接触多模态交互助手", (24, 16), self.font_bold, (255, 255, 255))
        frame = self._put_text(frame, f"当前场景：{scene['name']}", (390, 18), self.font, (0, 220, 255))
        frame = self._put_text(frame, f"识别手势：{gesture}  ({score:.2f})", (760, 18), self.font, (120, 240, 120))
        frame = self._put_text(frame, f"页面：{self.scene_page}", (1080, 18), self.font, (255, 220, 80))

        # 左侧界面
        self._draw_panel(frame, 18, 94, 430, 430, alpha=0.55)
        frame = self._put_text(frame, "场景说明", (38, 110), self.font_bold, (255, 255, 255))
        frame = self._put_text(frame, scene["desc"], (38, 156), self.font, (220, 220, 220))
        frame = self._put_text(frame, "可用手势", (38, 214), self.font_bold, (255, 255, 255))
        y = 258
        for k, v in list(scene["commands"].items())[:8]:
            frame = self._put_text(frame, f"{k:<6} → {v}", (38, y), self.font_small, (200, 230, 255))
            y += 34

        # 中间界面
        self._draw_panel(frame, 18, 450, 430, h - 18, alpha=0.52)
        frame = self._put_text(frame, "实时状态", (38, 466), self.font_bold, (255, 255, 255))
        frame = self._put_text(frame, f"语音：{self.voice.status_text}", (38, 520), self.font_small, (240, 240, 240))
        frame = self._put_text(frame, f"转写：{(self.latest_transcript[:28] + '...') if len(self.latest_transcript) > 28 else self.latest_transcript}", (38, 560), self.font_small, (240, 240, 240))
        frame = self._put_text(frame, "AI回复：", (38, 612), self.font_small, (240, 240, 240))
        reply = self.latest_reply if self.latest_reply else "等待触发..."
        reply_lines = []
        tmp = reply
        while tmp:
            reply_lines.append(tmp[:26])
            tmp = tmp[26:]
            if len(reply_lines) >= 4:
                break
        yy = 646
        for line in reply_lines[:4]:
            frame = self._put_text(frame, line, (38, yy), self.font_small, (255, 220, 120))
            yy += 30

        # 右侧界面
        self._draw_panel(frame, w - 390, 94, w - 18, h - 18, alpha=0.50)
        frame = self._put_text(frame, "最近事件", (w - 370, 110), self.font_bold, (255, 255, 255))
        yy = 158
        for ev in list(self.events)[:8]:
            frame = self._put_text(frame, ev[:22], (w - 370, yy), self.font_small, (230, 230, 230))
            yy += 36

        # 底部
        self._draw_panel(frame, 450, h - 92, w - 410, h - 18, alpha=0.62)
        frame = self._put_text(frame, self.command_hint, (470, h - 72), self.font_small, (255, 255, 255))

        #手势焦点标记
        cv2.circle(frame, center, 10, (0, 220, 255), 2, cv2.LINE_AA)
        cv2.line(frame, (center[0] - 18, center[1]), (center[0] + 18, center[1]), (0, 220, 255), 1, cv2.LINE_AA)
        cv2.line(frame, (center[0], center[1] - 18), (center[0], center[1] + 18), (0, 220, 255), 1, cv2.LINE_AA)

        return frame

    def _draw_no_camera_screen(self):
        frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
        frame[:] = self.config.col_bg
        frame = self._put_text(frame, "无法打开摄像头", (70, 100), self.font_bold, (255, 255, 255))
        frame = self._put_text(frame, "请检查摄像头权限、占用情况或 CAMERA_INDEX", (70, 155), self.font, (220, 220, 220))
        frame = self._put_text(frame, "按 Q 退出", (70, 210), self.font, (0, 220, 255))
        return frame

    def run(self):
        if not MEDIA_PIPE_AVAILABLE:
            raise RuntimeError("mediapipe is required for gesture recognition. Install mediapipe and try again.")

        cv2.namedWindow("No-Touch Multimodal Assistant", cv2.WINDOW_NORMAL)
        cv2.resizeWindow("No-Touch Multimodal Assistant", self.width, self.height)

        while True:
            if self.freeze:
                frame = getattr(self, "_frozen_frame", None)
                if frame is None:
                    ok, raw = self.cap.read()
                    if not ok:
                        frame = self._draw_no_camera_screen()
                    else:
                        frame = raw.copy()
                        self._frozen_frame = frame.copy()
                else:
                    frame = self._frozen_frame.copy()
            else:
                ok, frame = self.cap.read()
                if not ok:
                    frame = self._draw_no_camera_screen()
                    frame = self._put_text(frame, "请确认摄像头可用后重试。", (70, 270), self.font, (255, 180, 80))
                    cv2.imshow("No-Touch Multimodal Assistant", frame)
                    key = cv2.waitKey(30) & 0xFF
                    if key in (ord("q"), 27):
                        break
                    continue
                self._frozen_frame = frame.copy()

            frame = cv2.flip(frame, 1)
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.gesture_engine.process(frame_rgb)

            gesture = "无"
            score = 0.0
            center = (self.width // 2, self.height // 2)
            hand_count = 0

            if results.multi_hand_landmarks:
                hand_count = len(results.multi_hand_landmarks)
                labels = []
                scores = []
                centers = []
                handedness_list = results.multi_handedness or []
                for idx, hand_lms in enumerate(results.multi_hand_landmarks):
                    handedness_label = None
                    if idx < len(handedness_list):
                        try:
                            handedness_label = handedness_list[idx].classification[0].label
                        except Exception:
                            handedness_label = None
                    label, sc = self.gesture_engine.classify_single_hand(hand_lms, handedness_label, self.width, self.height)
                    labels.append(label)
                    scores.append(sc)
                    self.gesture_engine.draw_landmarks(frame, hand_lms)
                    lm = hand_lms.landmark
                    c = Utils.mid(
                        GestureEngine._pt(lm, 0, self.width, self.height),
                        GestureEngine._pt(lm, 9, self.width, self.height),
                    )
                    centers.append(c)

                if len(results.multi_hand_landmarks) >= 2:
                    gesture, score, center = self.gesture_engine.classify_two_hands(
                        results.multi_hand_landmarks[0],
                        results.multi_hand_landmarks[1],
                        self.width,
                        self.height,
                    )
                else:
                    gesture = labels[0]
                    score = scores[0]
                    center = centers[0]

                swipe = self.gesture_engine.detect_swipe(center)
                if swipe != "无" and gesture in ("五指张开", "食指指向", "无"):
                    gesture = swipe
                    score = max(score, 0.75)

            stable, stable_score = self._smooth_gesture(gesture, score)
            if stable != "无":
                gesture = stable
                score = stable_score

            self.latest_frame_gesture = gesture
            self.latest_hand_count = hand_count
            self.latest_confidence = score
            self.current_center = center

            now = time.time()
            if gesture != "无" and (gesture != self.last_triggered_gesture or now - self.last_trigger_time > self.config.gesture_cooldown):
                self.last_triggered_gesture = gesture
                self.last_trigger_time = now
                self._push_event(f"识别到手势：{gesture}")
                self.trigger_effects(gesture, center)
                self._apply_command(gesture)

            self.animations.update_and_draw(frame)
            frame = self._draw_hud(frame, gesture, score, center)

            if self.show_help:
                frame = self._put_text(
                    frame,
                    "快捷键：1会议 2医疗 3终端 | V语音 | H帮助 | 空格暂停 | S截图 | Q退出",
                    (28, self.height - 120),
                    self.font_small,
                    (255, 255, 255),
                )
            else:
                frame = self._put_text(
                    frame,
                    "按 H 显示帮助",
                    (28, self.height - 120),
                    self.font_small,
                    (180, 180, 180),
                )

            cv2.imshow("No-Touch Multimodal Assistant", frame)
            key = cv2.waitKey(1) & 0xFF

            if key in (ord("q"), 27):
                break
            elif key == ord("1"):
                self._switch_scene("meeting")
            elif key == ord("2"):
                self._switch_scene("medical")
            elif key == ord("3"):
                self._switch_scene("kiosk")
            elif key == ord("h"):
                self.show_help = not self.show_help
            elif key == ord(" "):
                self.freeze = not self.freeze
                self._push_event("暂停画面" if self.freeze else "恢复画面")
            elif key == ord("s"):
                ts = time.strftime("%Y%m%d_%H%M%S")
                path = f"snapshot_{ts}.jpg"
                cv2.imwrite(path, frame)
                self._push_event(f"已保存截图：{path}")
            elif key == ord("v"):
                if self.voice.recording:
                    self._push_event("语音录制中，请稍候...")
                elif self.voice.can_record():
                    self._push_event("开始录音")
                    self.voice.start_record_and_transcribe_async(
                        self.config.voice_record_seconds,
                        self.config.sample_rate,
                        self._record_done,
                    )
                else:
                    self._push_event("缺少录音依赖")
            elif key == ord("r"):
                self.scene_page = 1
                self.latest_reply = "已重置页面"
                self._push_event("重置当前页面")

        self.cap.release()
        cv2.destroyAllWindows()


def main():
    app = TouchlessAssistantApp()
    app.run()


if __name__ == "__main__":
    main()
